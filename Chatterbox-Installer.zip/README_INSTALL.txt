==================================================
Chatterbox TTS Extended Installer
==================================================

Thank you for downloading Chatterbox TTS Extended!

To install the application, please follow these steps:

1. Extract all the files from this zip archive to a folder on your computer.
2. Double-click on the `install.bat` file to begin the installation process.
   This will download and install all the necessary dependencies.
3. Once the installation is complete, you can run the application by double-clicking on the `run.bat` file.

Enjoy!
